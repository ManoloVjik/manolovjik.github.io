# manolovjik.github.io
#Yudenko Michael 29.01.2022
#My experiment with classes and objects.
#Whole code is unic and Yudenko Mike is the author of it.
#Coding by JavaScript with Visual Studio Code and p5.js librariries.
#(c) 2022
